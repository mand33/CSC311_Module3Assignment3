package org.example.csc311_module3assignment3;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.stage.Stage;

public class MazeApplication extends Application {

    @Override
    public void start(Stage stage) {
        TabPane tabPane = new TabPane();

        Tab tab1 = buildTab("maze.png", "Maze 1");
        Tab tab2 = buildTab("maze2.png", "Maze 2");

        tabPane.getTabs().addAll(tab1, tab2);

        Scene scene = new Scene(tabPane);
        stage.setTitle("Maze");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    private Tab buildTab(String mazeFile, String title) {
        Tab tab = new Tab(title);
        tab.setClosable(false);

        MazePane mazePane = new MazePane(mazeFile);
        tab.setContent(mazePane.getLayout());

        tab.setOnSelectionChanged(e -> {
            if (tab.isSelected()) {
                mazePane.requestCanvasFocus();
            }
        });

        return tab;
    }
}