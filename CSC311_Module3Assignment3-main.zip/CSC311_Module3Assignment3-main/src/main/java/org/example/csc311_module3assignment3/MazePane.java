package org.example.csc311_module3assignment3;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

public class MazePane implements MazeController.MazeListener {

    private final BorderPane root = new BorderPane();
    private final Canvas canvas;
    private final GraphicsContext gc;

    private final Button autoBtn = new Button("Auto");
    private final Button resetBtn = new Button("Reset");
    private final Button toggleBtn = new Button("Switch to Car");

    private final Label statusLabel = new Label("Ready - use arrow keys to move");

    private final MazeController controller;
    private final Timeline autoTimeline;

    private Image robotImage;

    private boolean useCar = false;

    public MazePane(String mazeFile) {
        controller = new MazeController(mazeFile, this);

        Image mazeImg = controller.getMazeImage();
        double w = mazeImg.getWidth();
        double h = mazeImg.getHeight();

        canvas = new Canvas(w, h);
        gc = canvas.getGraphicsContext2D();

        try {
            String path = "/org/example/csc311_module3assignment3/robot.png";
            robotImage = new Image(getClass().getResourceAsStream(path));
        } catch (Exception e) {
            robotImage = null;
        }

        VBox center = new VBox(canvas);
        center.setAlignment(Pos.CENTER);
        center.setPadding(new Insets(10));
        root.setCenter(center);

        HBox controls = new HBox(10, autoBtn, resetBtn, toggleBtn);
        controls.setAlignment(Pos.CENTER);

        VBox bottom = new VBox(10, controls, statusLabel);
        bottom.setAlignment(Pos.CENTER);
        bottom.setPadding(new Insets(10));
        root.setBottom(bottom);

        root.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            int speed = controller.getMoveSpeed();
            KeyCode code = e.getCode();

            if (code == KeyCode.RIGHT) {
                controller.tryMove(speed, 0, Car.RIGHT);
                e.consume();
            } else if (code == KeyCode.LEFT) {
                controller.tryMove(-speed, 0, Car.LEFT);
                e.consume();
            } else if (code == KeyCode.UP) {
                controller.tryMove(0, -speed, Car.UP);
                e.consume();
            } else if (code == KeyCode.DOWN) {
                controller.tryMove(0, speed, Car.DOWN);
                e.consume();
            }
        });

        root.setOnMouseClicked(e -> requestCanvasFocus());

        autoTimeline = new Timeline(
                new KeyFrame(Duration.millis(40), e -> controller.doAutoStep())
        );
        autoTimeline.setCycleCount(Timeline.INDEFINITE);

        autoBtn.setOnAction(e -> toggleAuto());
        resetBtn.setOnAction(e -> doReset());
        toggleBtn.setOnAction(e -> toggleMode());

        draw();
    }

    private void toggleMode() {
        useCar = !useCar;

        if (useCar) {
            toggleBtn.setText("Switch to Robot");
            statusLabel.setText("Car Mode");
        } else {
            toggleBtn.setText("Switch to Car");
            statusLabel.setText("Robot Mode");
        }

        draw();
        requestCanvasFocus();
    }

    private void toggleAuto() {
        if (controller.isRunning()) {
            controller.setRunning(false);
            autoTimeline.stop();
            autoBtn.setText("Auto");
        } else {
            controller.setRunning(true);
            autoTimeline.play();
            autoBtn.setText("Stop");
        }
        requestCanvasFocus();
    }

    private void doReset() {
        controller.setRunning(false);
        autoTimeline.stop();
        autoBtn.setText("Auto");
        controller.reset();
        requestCanvasFocus();
        draw();
    }

    public BorderPane getLayout() {
        return root;
    }

    public void requestCanvasFocus() {
        canvas.requestFocus();
    }

    @Override
    public void onPositionChanged() {
        draw();
    }

    @Override
    public void onStatusChanged(String message) {
        statusLabel.setText(message);
    }

    @Override
    public void onExitReached() {
        controller.setRunning(false);
        autoTimeline.stop();
        autoBtn.setText("Auto");
    }

    private void draw() {
        Image mazeImg = controller.getMazeImage();

        gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
        gc.drawImage(mazeImg, 0, 0);

        int x = controller.getX();
        int y = controller.getY();
        int sz = controller.getSpriteSize();

        if (!useCar && robotImage != null) {
            gc.drawImage(robotImage, x, y, sz, sz);
        } else {
            controller.getCar().draw(gc);
        }
    }
}