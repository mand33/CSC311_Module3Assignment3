package org.example.csc311_module3assignment3;

import javafx.scene.image.Image;
import javafx.scene.image.PixelReader;
import javafx.scene.paint.Color;

public class MazeController {

    public interface MazeListener {
        void onPositionChanged();
        void onStatusChanged(String message);
        void onExitReached();
    }

    private final String mazeFile; // ✅ add this

    private Image mazeImage;
    private PixelReader pixelReader;

    private int x;
    private int y;
    private int currentDir;

    private int spriteSize = 20;
    private int moveSpeed = 2;
    private boolean running = false;

    private Car car;
    private MazeListener listener;

    public MazeController(String mazeFile, MazeListener listener) {
        this.mazeFile = mazeFile; // ✅ store it
        this.listener = listener;
        this.currentDir = Car.RIGHT;

        try {
            String path = "/org/example/csc311_module3assignment3/" + mazeFile;
            mazeImage = new Image(getClass().getResourceAsStream(path));
            pixelReader = mazeImage.getPixelReader();
        } catch (Exception e) {
            System.out.println("Could not load maze image");
        }

        findStartPosition();
        car = new Car(x, y);
    }

    private void findStartPosition() {
        if (mazeImage == null || pixelReader == null) {
            x = 3;
            y = 10;
            return;
        }

        int w = (int) mazeImage.getWidth();
        int h = (int) mazeImage.getHeight();
        int sz = spriteSize;

        // ✅ Maze 2: scan from RIGHT edge, Maze 1: scan from LEFT edge
        boolean isMaze2 = mazeFile != null && mazeFile.toLowerCase().contains("maze2");
        int entranceX = isMaze2 ? (w - sz - 2) : 1;

        for (int row = 0; row <= h - sz; row++) {
            if (canGoTo(entranceX, row)) {
                x = entranceX;
                y = row;
                return;
            }
        }

        // fallback: first white area anywhere
        for (int row = 0; row <= h - sz; row++) {
            for (int col = 0; col <= w - sz; col++) {
                if (canGoTo(col, row)) {
                    x = col;
                    y = row;
                    return;
                }
            }
        }

        x = 3;
        y = 10;
    }

    // ... keep the rest of your class unchanged ...
    public boolean isPathPixel(int px, int py) {
        if (pixelReader == null) return false;
        if (px < 0 || py < 0) return false;
        if (px >= (int) mazeImage.getWidth()) return false;
        if (py >= (int) mazeImage.getHeight()) return false;

        Color c = pixelReader.getColor(px, py);
        return c.getRed() > 0.78 && c.getGreen() > 0.78 && c.getBlue() > 0.78;
    }

    public boolean canGoTo(int newX, int newY) {
        int sz = spriteSize;

        boolean tl  = isPathPixel(newX, newY);
        boolean tr  = isPathPixel(newX + sz - 1, newY);
        boolean bl  = isPathPixel(newX, newY + sz - 1);
        boolean br  = isPathPixel(newX + sz - 1, newY + sz - 1);
        boolean mid = isPathPixel(newX + sz / 2, newY + sz / 2);

        return tl && tr && bl && br && mid;
    }

    public void tryMove(int dx, int dy, int dir) {
        int steps = Math.abs(dx != 0 ? dx : dy);

        int stepX = Integer.compare(dx, 0);
        int stepY = Integer.compare(dy, 0);

        for (int i = 0; i < steps; i++) {
            int nx = x + stepX;
            int ny = y + stepY;

            if (canGoTo(nx, ny)) {
                x = nx;
                y = ny;
                car.setX(x);
                car.setY(y);
                car.setHeading(dir);
            } else {
                break;
            }
        }

        currentDir = dir;
        listener.onPositionChanged();
        checkExit();
    }

    private void checkExit() {
        if (mazeImage == null) return;

        if (x + spriteSize >= (int) mazeImage.getWidth() - 2) {
            running = false;
            listener.onStatusChanged("You made it out!");
            listener.onExitReached();
        }
    }

    public void reset() {
        running = false;
        findStartPosition();
        car.setX(x);
        car.setY(y);
        setCurrentDir(Car.RIGHT);
        listener.onPositionChanged();
        listener.onStatusChanged("Ready - use arrow keys to move");
    }

    public void doAutoStep() {
        if (!running) return;

        int leftDir  = turnLeft(currentDir);
        int rightDir = turnRight(currentDir);
        int backDir  = turnBack(currentDir);

        int[] tryOrder = { leftDir, currentDir, rightDir, backDir };

        for (int d : tryOrder) {
            int[] delta = getMoveDelta(d);
            int nx = x + delta[0];
            int ny = y + delta[1];

            if (canGoTo(nx, ny)) {
                currentDir = d;
                x = nx;
                y = ny;
                car.setX(x);
                car.setY(y);
                car.setHeading(d);
                listener.onPositionChanged();
                checkExit();
                return;
            }
        }

        running = false;
        listener.onStatusChanged("Stuck! Press Reset to try again.");
    }

    public void setCurrentDir(int dir) {
        currentDir = dir;
        if (car != null) car.setHeading(dir);
    }

    public void setRunning(boolean val) { running = val; }
    public boolean isRunning() { return running; }

    private int turnLeft(int dir) {
        if (dir == Car.RIGHT) return Car.UP;
        if (dir == Car.UP) return Car.LEFT;
        if (dir == Car.LEFT) return Car.DOWN;
        return Car.RIGHT;
    }

    private int turnRight(int dir) {
        if (dir == Car.RIGHT) return Car.DOWN;
        if (dir == Car.DOWN) return Car.LEFT;
        if (dir == Car.LEFT) return Car.UP;
        return Car.RIGHT;
    }

    private int turnBack(int dir) {
        if (dir == Car.RIGHT) return Car.LEFT;
        if (dir == Car.LEFT) return Car.RIGHT;
        if (dir == Car.UP) return Car.DOWN;
        return Car.UP;
    }

    private int[] getMoveDelta(int dir) {
        if (dir == Car.RIGHT) return new int[]{ moveSpeed, 0 };
        if (dir == Car.LEFT)  return new int[]{ -moveSpeed, 0 };
        if (dir == Car.DOWN)  return new int[]{ 0, moveSpeed };
        if (dir == Car.UP)    return new int[]{ 0, -moveSpeed };
        return new int[]{ 0, 0 };
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public int getSpriteSize() { return spriteSize; }
    public int getMoveSpeed() { return moveSpeed; }
    public Car getCar() { return car; }
    public Image getMazeImage() { return mazeImage; }
}